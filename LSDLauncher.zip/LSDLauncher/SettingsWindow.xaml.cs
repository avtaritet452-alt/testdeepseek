using System;
using System.Windows;
using System.Windows.Input;

namespace LSDLauncher
{
    public partial class SettingsWindow : Window
    {
        private Settings settings;
        private MainWindow mainWindow;

        public SettingsWindow(MainWindow mainWindow, Settings settings)
        {
            InitializeComponent();
            this.mainWindow = mainWindow;
            this.settings = settings;
            DiscordCheckBox.IsChecked = settings.DiscordRPCEnabled;
            RandomNickCheckBox.IsChecked = settings.RandomNicknameEachLaunch;
            KeepFilesCheckBox.IsChecked = settings.KeepFiles;
        }

        private void RandomNickButton_Click(object sender, RoutedEventArgs e)
        {
            string randomNick = GenerateRandomNick();
            RandomNickPreview.Text = randomNick;
            mainWindow.SetRandomNick(randomNick);
        }

        private string GenerateRandomNick()
        {
            string[] prefixes = { "Pro", "Super", "Mega", "Ultra", "Cool", "Fast", "Dark", "Light", "Crazy", "Smart" };
            string[] suffixes = { "Player", "Gamer", "Tee", "Runner", "Master", "Killer", "Hunter", "Lord", "King", "Wolf" };
            string[] numbers = { "", "1", "2", "3", "4", "5", "7", "9", "13", "42", "99" };
            Random rnd = new Random();
            return prefixes[rnd.Next(prefixes.Length)] + suffixes[rnd.Next(suffixes.Length)] + numbers[rnd.Next(numbers.Length)];
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            settings.DiscordRPCEnabled = DiscordCheckBox.IsChecked ?? true;
            settings.RandomNicknameEachLaunch = RandomNickCheckBox.IsChecked ?? false;
            settings.KeepFiles = KeepFilesCheckBox.IsChecked ?? false;
            settings.Save();
            mainWindow.ApplySettings(settings);
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}